// site.js
// this is where you would put your Google Analytics tag and other global js codes.
// Starting with <script...>
