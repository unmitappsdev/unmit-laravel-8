<?php return array (
  'home' => 
  array (
    'announcement' => 'green::Welcome',
    'prelogin-note' => 'Pre-login message here',
    'prelogin-compatibility-msg' => '<p>This application works on the minimum version of the following browsers: <ul> <li>Google Chrome v84</li> <li>Apple Safari v13</li> <li>Mozilla Firefox v79</li> <li>Microsoft Edge v86</li> </ul> </p> <p>This application does NOT work with the following browser: <ul> <li>Internet Explorer</li> </ul> </p>',
    'postlogin-not-authorized' => 'Sorry, you don\'t have enough access rights to use this application.',
    'postlogin-header-msg' => 'This message appears after the user is given the access right, aka authorized, via ./app/Providers/AuthServiceProvider.php',
    'postlogin-contact-msg' => '<p style="font-weight:bold;">Contact message here</p>',
  ),
);
