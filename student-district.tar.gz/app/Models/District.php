<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\OracleModel;

class District extends OracleModel
{
	use HasFactory;

}
