<?php

namespace App\Http\Controllers;

use JavaScript;
use App\Models\District;
// use Illuminate\Http\Request;
use App\Http\Requests\District as DistrictFR;
use Illuminate\Support\Facades\Validator;

class DistrictController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$target_tag = 'district-index';

		$pass_var = [
			'_fqdn' => $this->basedomain,
			'_basePath' => 'district',
			'_apiurl' => route('data.district.index'),
			'_csrf_token' => csrf_token(),
			'_target_tag' => $target_tag,
			'_oauth_token_type' => session()->get('api.token_type',null)[0] ?? null,
			'_oauth_access_token' => session()->get('api.access_token',null)[0] ?? null,
			'_table_attributes' => $this->getTableAttributes($target_tag,new District)
		];

		JavaScript::put($pass_var);

		return view('district.index',compact('target_tag'));
	}

	public function form($id = false)
	{
		if ($id) {
			$target_tag = 'district-edit';
		} else {
			$target_tag = 'district-create';
		}

		$pass_var = [
			'_fqdn' => $this->basedomain,
			'_basePath' => 'district',
			'_apiurl' => route('data.district.find'),
			'_saveformCallback' => $id ? route('district.update'):route('district.store'),
			'_record_id' => $id ?? 0,
			'_csrf_token' => csrf_token(),
			'_target_tag' => $target_tag,
            '_oauth_token_type' => session()->get('api.token_type',null)[0] ?? null,
            '_oauth_access_token' => session()->get('api.access_token',null)[0] ?? null,
			'_form_attributes' => $id ? $this->getFormAttributes($target_tag,['id'=>$id]):$this->getFormAttributes($target_tag),
			'_old' => request()->old()
		];

		JavaScript::put($pass_var);

		return view('district.create',compact('target_tag','id'));
	}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
	{
		return $this->form();
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DistrictFR $request)
	{
		$newval = [];

		$validator = Validator::make($request->all(),$request->rules(),$request->messages());

		if ($validator->validated()) {
			$model = new \App\Models\District;

			$model->id = $request['sbgi_code'];
			$model->district_code = $request['district_code'];
			$model->district_name = $request['district_name'];
			$model->type_ind = $request['institution_type'];
			$model->activity_date = date('Y-M-j H:i:s',time());

			$model->save();
		}

		return view('district.store-confirmed');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\District  $district
     * @return \Illuminate\Http\Response
     */
    public function show(District $district)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\District  $district
     * @return \Illuminate\Http\Response
     */
    public function edit(District $district)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\District  $district
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, District $district)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\District  $district
     * @return \Illuminate\Http\Response
     */
    public function destroy(District $district)
    {
        //
    }
}
