@extends('layouts.base')

@section('main-title','List of District')

@section('breadcrumb')
{{-- <li><a href="{{ route('request.main') }}">Districts</a></li> --}}
<li>List</li>
@endsection

@section('content')
<div id="primary">
  <div class="row">
    <div class="col-md-10">
		<h1>View All Districts</h1>
    </div>
	<div class="col-md-2">
		<a class="btn btn-success" href="{{ route('district.create') }}">Add a new district</a>
	</div>
  </div>
  <div class="spacer25"></div>
  <div id="{{ $target_tag }}"></div>
</div>
@endsection

@section('scripts')
	<script src="{{ mix('js/components/List.js') }}" type="module"></script>
@endsection
