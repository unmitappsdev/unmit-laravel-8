@extends('layouts.base')

@section('main-title','Requests > Activity')

@section('breadcrumb')
<li><a href="{{ route('district.index') }}">District</a></li>
<li>{{ $id ? 'Edit':'New' }} District</li>
@endsection

@section('content')
<div id="primary">

  <div class="row">

    <div class="col-md-12">
@if ($id)
      <h1>Edit a District record (#{{ $id }})</h1>
@else
      <h1>Create a New District record</h1>
@endif
@lang('text.district.header-msg')
    </div>

  </div>

  <div class="spacer25"></div>

@if (session('errormsg'))
  <div class="alert alert-danger" role="alert">{{ session('errormsg') }}</div>
@endif

@foreach ($errors->all() as $message)
  <div class="alert alert-danger" role="alert">{{ $message }}</div>
@endforeach

  <div class="well">
	<div id="{{ $target_tag }}"></div>
	<div class="spacer35"></div>
  </div>
</div>
@endsection

@section('scripts')
@if ($id)
	<script src="{{ mix('js/components/Edit.js') }}" type="module"></script>
@else
	<script src="{{ mix('js/components/Add.js') }}" type="module"></script>
@endif
<script>
$(document).ready(function() {
	$(":submit").click(function(e) {
		e.preventDefault();
		$("button:submit").attr("disabled",true);
		$('form').submit();
	});
});
</script>
@endsection
