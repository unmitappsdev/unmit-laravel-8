@extends('layouts.base')

@section('main-title','District > Added a new record')

@section('breadcrumb')
<li><a href="{{ route('district.index') }}">District</a></li>
<li>New District</li>
@endsection

@section('content')
<div id="primary">

  <div class="row">

    <div class="col-md-12">
      <h1>District Submitted/Updated</h1>
    </div>

  </div>

  <div class="spacer25"></div>

  <div class="well">
	<p>This district has been successfully added.</p>
	<div class="spacer35"></div>
	<a class="btn btn-success" href="{{ ($redirect_route ?? false) ? route($redirect_route):route('district.index') }}">Return to District Index</a>
  </div>
</div>
@endsection

